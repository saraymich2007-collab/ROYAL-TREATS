# ROYAL TREATS - Web gratuita

Esta carpeta contiene una página web estática lista para publicar en GitHub Pages.

## Antes de publicar
En `index.html`, reemplaza:
- `AGREGA AQUÍ TU NÚMERO`
- `AGREGA AQUÍ TU @USUARIO`
- `AGREGA AQUÍ TU CORREO`

También reemplaza el botón de Wompi por el enlace de checkout que genere la cuenta de Wompi de ROYAL TREATS.

## Publicación
1. Crea una cuenta en GitHub.
2. Crea un repositorio público llamado `royal-treats`.
3. Sube `index.html`.
4. Ve a Settings > Pages.
5. En Source selecciona `Deploy from a branch`.
6. Selecciona la rama `main` y la carpeta `/ (root)`.
7. Guarda y espera a que GitHub publique el sitio.

La web queda disponible con una dirección similar a:
https://TU-USUARIO.github.io/royal-treats/
